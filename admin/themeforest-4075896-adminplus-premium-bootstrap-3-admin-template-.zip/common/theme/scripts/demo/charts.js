/* ==========================================================
 * AdminPlus v3.0
 * charts.js
 * 
 * http://www.mosaicpro.biz
 * Copyright MosaicPro
 * 
 * Built exclusively for sale @Envato Marketplaces
 * ========================================================== */ 

$(function()
{
	// initialize charts
	if (typeof charts != 'undefined') 
		charts.initCharts();
});